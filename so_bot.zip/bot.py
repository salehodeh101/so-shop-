
import telebot

TOKEN = "ضع_توكن_البوت_هنا"

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "أهلاً بك في بوت متجر سو 👋")

bot.polling()
